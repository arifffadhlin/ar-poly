﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MessageBox : MonoBehaviour
{
    public static int score;
    public GameObject box; //contain box
    public Text message; //contain message
    public string[] messagelist; //contain all the messages
    public Image img;
    


    public void showmessage (int answerindex,string description)
    {
        message.text = messagelist[answerindex];
        message.text += "\n" + description;
        box.SetActive(true);
    }

    public void ShowScore()
    {
        img.rectTransform.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, 450);
        img.rectTransform.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, 300);

        if (score <= 20)
        {
            message.text = "You are on beginner level of knowledge in Entrepreneurship!";
        }
        else if (score >20 && score <50)
        {
            message.text = "Good, you are not further away from becoming a good entrepreneur!";
        }
        else
        {
            message.text = "Congratulation!! You are one step away to become an exemplary entrepreneur!";
        }

        box.SetActive(true);


    }
}
