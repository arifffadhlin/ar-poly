﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player : MonoBehaviour
{
    int score = 0;
    public List<Quiz> quizList = new List<Quiz>();
    int currentQuizIndex;
    public Text scoreText;
    int checkpoint = 0; // save checkpoint

    public void CalculateScore(int point)
    {
        score += point;
        MessageBox.score = score;
        scoreText.text = "Score: " + score;
    }
    // Start is called before the first frame update
    void Start()
    {
        currentQuizIndex = 0;
    }

    public void Progress(int correct)
    {
        if(correct == 1)
        {
            // ke depan
            Debug.Log("Player advances.");

            if(currentQuizIndex < quizList.Count) 
                currentQuizIndex = currentQuizIndex + 1;

           // if (currentQuizIndex == 3 || currentQuizIndex == 6) 
          //  {
               // checkpoint = currentQuizIndex; // save checkpoint at Q4 and Q7
            //    Debug.Log("Saved checkpoint at Question " + (checkpoint + 1));
            // }
                
        }
        else
        {
            // ke belakang
            Debug.Log("Player retreats.");
            if (currentQuizIndex > 0 /* && checkpoint < 3*/)
                currentQuizIndex = currentQuizIndex - 1;
          //  else
           // {
          //      currentQuizIndex = checkpoint; // load checkpoint
          //      Debug.Log("Load checkpoint at Question " + (checkpoint + 1));
           // }
                
        }
    }

    public void CheckCurrentPosition(int index)
    {
        if(currentQuizIndex == index)
        {
            quizList[index].gameObject.SetActive(true);
        }
        else
        {
            quizList[index].gameObject.SetActive(false);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
