﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuizGenerator : MonoBehaviour
{
    [TextArea]
    public string[] questions;
    public Vector3[] answers;
    public bool[] isAnswered;
    [TextArea]
    public string[] description;

 

    public int GenerateQuiz()
    {
        int index;
        return index = Random.Range(0, questions.Length);
    }

    
}
