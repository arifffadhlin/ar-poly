﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Quiz : MonoBehaviour
{
    int isCorrect = 0;
    int point;
    public int pointInc = 10;
    public int pointDec = -10;
    bool isAnswered = false;
    public Player player;
    public QuizGenerator generator;
    string question;
    public Text questionText;
    public Vector3 answers;
    public MessageBox box;
    int questionindex;

    public void SetQuiz()
    {
        questionindex = generator.GenerateQuiz();
        question = generator.questions[questionindex]; // generate question
        questionText.text = question; // assign question to Text
        answers = generator.answers[questionindex]; // generate answer
    }
    public void ResetQuiz()
    {
        if (isAnswered)
        {
            SetQuiz();
            isAnswered = false;
        }
    }

    public void Answer(int index)
    {
        int answer = 0;
        if (index == 0) answer = (int) answers.x; // pilih A
        else if (index == 1) answer = (int)answers.y; // pilih B
        else if (index == 2) answer = (int)answers.z; // pilih C

        if (!isAnswered)
        {
            isCorrect = answer; // betul ke salah
            Debug.Log("The answer is " + isCorrect);
            isAnswered = true; // Dah jawab
            if (isCorrect == 1) // 1 = betul
            {
                box.showmessage(0,generator.description[questionindex]);
                point = pointInc;
            }
            else // 0 = salah
            {
                box.showmessage(1,generator.description[questionindex]);
                point = pointDec;
            }
            player.CalculateScore(point);
            player.Progress(isCorrect);
        }
        ResetQuiz();
        gameObject.SetActive(false);
    }
    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();
        SetQuiz();
        box = GameObject.Find("Canvas").GetComponent<MessageBox>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
